#ifndef __COMMON_H__
#define __COMMON_H__

typedef unsigned char uint8_t;






#endif
